export enum Roles { 
    Admin,
    Guest
  }
  